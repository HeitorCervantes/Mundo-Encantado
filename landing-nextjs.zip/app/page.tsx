
import './globals.css'
import LandingPage from '../components/LandingPage'

export default function Page() {
  return <LandingPage />
}
